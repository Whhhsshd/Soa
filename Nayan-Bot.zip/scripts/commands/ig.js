/** Đổi Credit ? Bọn t đã không mã hóa cho mà edit rồi thì tôn trọng nhau tý đi ¯\_(ツ)_/¯ **/
module.exports.config = {
  name: `${global.config.PREFIX}`,
  version: "1.0.0", 
  permission: 0,
  credits: "nayan",
  description: "", 
  prefix: true,
  category: "user",
  usages: "",
  cooldowns: 5, 
  dependencies: {
	}
};


module.exports.run = async({api,event,args,client,Users,Threads,__GLOBAL,Currencies}) => {
const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
   var hi = ["𝗗𝗥𝗔𝗚𝗢𝗡 𝗕𝗢𝗧𝗡𝗘𝗧 𝗦𝗧𝗔𝗥𝗧𝗘𝗗 ! 𝗨𝗦𝗘 !help 𝗧𝗢 𝗦𝗘𝗘 𝗠𝗢𝗥𝗘"
             ];
  var know = hi[Math.floor(Math.random() * hi.length)];
  var link = [
  "https://i.postimg.cc/RF8nWqH0/on-X.jpg",
   "https://i.postimg.cc/QMv7f0Xb/b94d0292-1f78-4221-b903-4abe57e06207.jpg",
    "https://i.postimg.cc/KzsHpX1W/b53aa72a-3b77-4c10-a03e-aafb94a53f79.jpg",

  
];
	 var callback = () => api.sendMessage({body:`「 ${know} 」`,attachment: fs.createReadStream(__dirname + "/cache/5.jpg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/5.jpg"));	
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/5.jpg")).on("close",() => callback());
   };